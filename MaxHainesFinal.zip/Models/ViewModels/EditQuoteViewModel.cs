﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QuoteFinal.Models.ViewModels
{
    //creates a different editable quote object
    public class EditQuoteViewModel
    {
        public Quote Quote { get; set; }
    }
}
